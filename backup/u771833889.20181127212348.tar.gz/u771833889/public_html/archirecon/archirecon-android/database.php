<?php

define('hostname', '');
define('user', 'u771833889_archi');
define('password', 'archirecon123');
define('db_name', 'u771833889_archi');
define('URL', 'http://www.logiswebmedia.com/archirecon/archirecon-android/');


?>