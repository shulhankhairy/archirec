<?php

define('hostname', 'localhost');
define('user', 'root');
define('password', '');
define('db_name', 'archireconDB');
define('URL', 'http://192.168.43.245/archirecon/');


?>