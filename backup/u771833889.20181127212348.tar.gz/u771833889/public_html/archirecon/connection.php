<?php

$con = mysql_connect("localhost", "u771833889_archi", "archirecon123") or die(mysql_error());
	mysql_select_db("u771833889_archi");
	
?>